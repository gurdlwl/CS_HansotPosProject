﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hansot_pos
{
    public class FoodType
    {
        public enum foodType
        {
            none,
            primeumGomei,
            square,
            bowl,
            side,
            drink
        }
    }
}
